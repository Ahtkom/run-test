﻿using System;

namespace testapp
{
    class GdalTest
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Testing GDAL C# Bindings");
        }
    }
}
