The coordinate reference systems that can be passed are anything supported by the
OGRSpatialReference.SetFromUserInput() call, which includes EPSG Projected,
Geographic or Compound CRS (i.e. EPSG:4296), a well known text (WKT) CRS definition,
PROJ.4 declarations, or the name of a .prj file containing a WKT CRS definition.
